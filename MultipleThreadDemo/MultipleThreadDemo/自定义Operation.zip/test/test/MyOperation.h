//
//  MyOperation.h
//  test
//
//  Created by sun on 2018/2/6.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyOperation : NSOperation
@property (nonatomic, assign, readonly) NSInteger number;
- (instancetype)initWithTaskNumber:(NSInteger)numer NS_DESIGNATED_INITIALIZER;
@end
