//
//  MyOperation.swift
//  test
//
//  Created by sun on 2018/2/6.
//  Copyright © 2018年 sun. All rights reserved.
//

import Cocoa

class SwiftOperation: Operation {

    private var _executing: Bool = false
    private var _finished: Bool = false
    private var number: Int = 0

    override var isExecuting: Bool {
        return _executing
    }
    override var isFinished: Bool {
        return _finished
    }

    init(number: Int) {
        self.number = number
    }
    override func main() {

        if isCancelled {
            self.willChangeValue(forKey: "isFinished")
            _finished = true
            self.didChangeValue(forKey: "isFinished")
            return
        }

        self.willChangeValue(forKey: "isExecuting")
        _executing = true
        print("开始任务.... \(self.number)")
        DispatchQueue.global().async { [weak self] in
            sleep(2)
            print("任务完成.... \(self?.number)")
            self?.completeOperation()
        }
        self.didChangeValue(forKey: "isExecuting")
    }

    private func completeOperation() {
        self.willChangeValue(forKey: "isFinished")
        self.willChangeValue(forKey: "isExecuting")
        _executing = false
        _finished = true
        self.didChangeValue(forKey: "isFinished")
        self.didChangeValue(forKey: "isExecuting")
    }

    deinit {
        print("SwiftOperation deinit: \(self.number)")
    }
    
}
