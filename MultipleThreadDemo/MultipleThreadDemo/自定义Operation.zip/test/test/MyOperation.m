//
//  MyOperation.m
//  test
//
//  Created by sun on 2018/2/6.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "MyOperation.h"

@implementation MyOperation
{
    BOOL        executing;
    BOOL        finished;
}
- (id)initWithTaskNumber:(NSInteger)number {
    if (self == [super init]) {
        executing = NO;
        finished = NO;
        _number = number;
    }
    return self;
}
- (void)start {

    if ([self isCancelled])
    {
        [self willChangeValueForKey:@"isFinished"];
        finished = YES;
        [self didChangeValueForKey:@"isFinished"];
        return;
    }

    [self willChangeValueForKey:@"isExecuting"];
    NSLog(@"开始执行任务: %ld %@", _number, [NSThread currentThread]);
    [NSThread detachNewThreadSelector:@selector(main) toTarget:self withObject:nil];
    executing = YES;
    [self didChangeValueForKey:@"isExecuting"];
}
- (void)main {

    @autoreleasepool {

        sleep(5);
        NSLog(@"任务: %ld 完成 %@", _number, [NSThread currentThread]);
        [self completeOperation];
    }

}
- (BOOL)isAsynchronous {
    return YES;
}

- (BOOL)isExecuting {
    return executing;
}

- (BOOL)isFinished {
    return finished;
}

- (void)completeOperation {
    [self willChangeValueForKey:@"isFinished"];
    [self willChangeValueForKey:@"isExecuting"];
    executing = NO;
    finished = YES;
    [self didChangeValueForKey:@"isExecuting"];
    [self didChangeValueForKey:@"isFinished"];
}
@end
