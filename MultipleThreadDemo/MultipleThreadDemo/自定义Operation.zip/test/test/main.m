//
//  main.m
//  test
//
//  Created by sun on 2018/2/6.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyOperation.h"
#import "test-Swift.h"

int main(int argc, const char * argv[]) {

//    dispatch_queue_t queue = dispatch_queue_create("xxxooo", NULL);
//
//    dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
//    dispatch_async(queue, ^{
//        NSLog(@"开始 1");
//        dispatch_async(dispatch_get_global_queue(0, 0), ^{
//            sleep(2);
//            NSLog(@"1 done");
//            dispatch_semaphore_signal(semaphore);
//        });
//    });
//
//    dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
//
//    dispatch_async(queue, ^{
//        NSLog(@"开始 2");
//        dispatch_async(dispatch_get_global_queue(0, 0), ^{
//            sleep(2);
//            NSLog(@"2 done");
//            dispatch_semaphore_signal(semaphore);
//        });
//    });




//    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
//    queue.maxConcurrentOperationCount = 3;
//
//    MyOperation *lastOp = nil;
//    for (NSInteger i = 1; i <= 5; i++) {
//        MyOperation *op = [[MyOperation alloc] initWithTaskNumber:i];
////        if (lastOp) {
////            [op addDependency:lastOp];
////        }
//        lastOp = op;
//
//        [queue addOperation:op];
//    }
//
//    NSBlockOperation *allOp = [NSBlockOperation blockOperationWithBlock:^{
//        NSLog(@"全部任务完成....");
//    }];
//
//    [allOp addDependency:lastOp];
//    [queue addOperation:allOp];

    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    queue.maxConcurrentOperationCount = 3;

    SwiftOperation *lastOp = nil;
    for (NSInteger i = 1; i <= 5; i++) {
        SwiftOperation *op = [[SwiftOperation alloc] initWithNumber:i];
        //        if (lastOp) {
        //            [op addDependency:lastOp];
        //        }
        lastOp = op;

        [queue addOperation:op];
    }

    NSBlockOperation *allOp = [NSBlockOperation blockOperationWithBlock:^{
        NSLog(@"全部任务完成....");
    }];

    [allOp addDependency:lastOp];
    [queue addOperation:allOp];

    [[NSRunLoop mainRunLoop] run];
    return 0;
}
